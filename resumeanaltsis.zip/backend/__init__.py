# backend/__init__.py
# Marks this folder as a Python package
